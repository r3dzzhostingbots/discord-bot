const CONFIG = {}; 
CONFIG.SECTIONS = [];
CONFIG.LOGS = "1450116004922392758"
CONFIG.TRANSCRIPT = "1450116044588056586"
CONFIG.DOMAIN = "https://www.royalteame.cf/"
CONFIG.Embed = { // رسالة تسطيب التذكرة 
    Title : `Robix Family`,
    Color: 'bfbfbf', // لون الايبمد
    Banner: 'https://cdn.discordapp.com/attachments/1450109614929481830/1450109939291783208/ChatGPT_Image_Dec_15_2025_04_55_44_AM.png?ex=6941579f&is=6940061f&hm=60ac902a98c30c4ec813ff93d47e051556ada70292ea5462a72bb04eaedc8a64&', // بنر التكت
    Description :
     `** اضغط على احدى الازرار بالاسفل لفتح تذكره شراء او استفسار
         Click one of the buttons below to open a purchase ticket or make an inquiry.**`// وصف التكت
}
CONFIG.SECTIONS.push(
    {
        SectionID: CONFIG.SECTIONS.length, 
        SectionName: "شراء منتج",
        SectionEmoji: "🛒",
        CategoryID: "1449148807228035183",
        ClosedTicketsCategoryID: '1449148807228035183',
        CloseTicketFromSupportOnly: false, // عدم السماح للإشخاص بإغلاق التذكرة فقط رتب الدعم الفني يمكنهم إغلاق التذكرة
        ClosedReason: false,
        //EmbedMessage: [// رسالة التكت
        Color: '#ac50a4',// لون الأمبد
        Banner: 'https://cdn.discordapp.com/attachments/1450109614929481830/1450109939291783208/ChatGPT_Image_Dec_15_2025_04_55_44_AM.png?ex=6941579f&is=6940061f&hm=60ac902a98c30c4ec813ff93d47e051556ada70292ea5462a72bb04eaedc8a64&',// بانر القسم
        //]
        MainSupportRolesID: "1449148723094355978", // الرتبه الي البوت يمنشنها
        SupportRolesID: [ 
            "1449148723094355978",// الرتبة المسؤولة عن القسم
        ]
    }
);
CONFIG.SECTIONS.push(
    {
        SectionID: CONFIG.SECTIONS.length, 
        SectionName:"استفسار عن منتج",
        SectionEmoji: "❔",
        CategoryID: "1449148803096510515",
        ClosedTicketsCategoryID: '1449148803096510515',
        CloseTicketFromSupportOnly: false, // عدم السماح للإشخاص بإغلاق التذكرة فقط رتب الدعم الفني يمكنهم إغلاق التذكرة
        ClosedReason: false,
        //EmbedMessage: [// رسالة التكت
        Color: '#ac50a4',// لون الأمبد
        Banner: 'https://cdn.discordapp.com/attachments/1450109614929481830/1450109939291783208/ChatGPT_Image_Dec_15_2025_04_55_44_AM.png?ex=6941579f&is=6940061f&hm=60ac902a98c30c4ec813ff93d47e051556ada70292ea5462a72bb04eaedc8a64&',// بانر القسم
        //]
        MainSupportRolesID: "1449148723094355978", // الرتبه الي البوت يمنشنها
        SupportRolesID: [ 
            "1449148723094355978",// الرتبة المسؤولة عن القسم
        ]
    }
);
module.exports = CONFIG;
module.exports = {
Setting: {
    Token: 'MTQ1MDExODQ4MzgzMTY4OTM2Ng.GUXahM.vD2YMGAbJrVr1LKJbFjy4P_JoYNhr8abmtHh5I',
    Prefix : '!',
    GuildId: '1448012055926804632',
},
DataBase: {
    Url : 'mongodb+srv://five:88uuii88@cluster0.jfrou.mongodb.net/ryno',
}
}